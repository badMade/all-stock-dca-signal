# core-repo-additions

One file, shipped separately from `dca-sizing-signals/` on purpose: `sizing_adjustment_reader.py`
is core-repo code, not a heavy-dependency sibling subproject. It's the one module allowed
to know that more than one `SizingSuggester` exists, and it belongs next to
`near_close_dca.py`, subject to the core repo's own stdlib-only ruff and coverage gates
(it already only uses the stdlib, so it fits that constraint as-is).

Bundling it inside `dca-sizing-signals/` instead would blur the exact line that
architecture is meant to draw: suggesters on one side, the one thing allowed to combine
their output on the other. Keep them apart when integrating.

Target location once merged: `<repo_root>/live_dca_side/sizing_adjustment_reader.py`, or
wherever `near_close_dca.py` itself lives if that's not a separate directory in the real repo.
