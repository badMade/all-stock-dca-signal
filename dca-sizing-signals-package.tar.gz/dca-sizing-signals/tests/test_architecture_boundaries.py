"""Enforces, at test level rather than by convention alone, that
independent forecasting/suggestion components never import each other or
the live DCA engine, and that the live engine never imports a concrete
suggester directly -- only dca_shared_interfaces.

Repo-root note, fixed during packaging: the original version of this test
assumed REPO_ROOT was two parents up from this file, which only held
under the flat sandbox layout it was first written in. Nested properly
here (dca-sizing-signals/tests/test_architecture_boundaries.py), that
same assumption would resolve to the wrong directory and silently check
nothing -- worse than failing loudly. This version instead:

  1. Reads DCA_REPO_ROOT from the environment if set (point this at the
     real all-stock-dca repo root once this package sits alongside
     ml-forecaster/ and wondrous-octopus/ there).
  2. Falls back to this package's own parent directory otherwise, and
     WARNS rather than silently passing if ml_forecaster/ and
     wondrous_octopus/ aren't found there -- this test does nothing
     useful for the cross-subproject checks until the real siblings are
     on disk next to it.
  3. Always runs one check that needs no configuration at all: nothing
     inside dca_shared_interfaces/ imports anything it shouldn't,
     checked relative to this package's own known layout.

Stdlib only (ast + pathlib + os + warnings), no new dependency.
"""

from __future__ import annotations

import ast
import os
import warnings
from pathlib import Path

REPO_ROOT = Path(os.environ.get("DCA_REPO_ROOT", str(Path(__file__).resolve().parents[2])))

# package directory name -> names it must never import
FORBIDDEN_IMPORTS: dict[str, set[str]] = {
    "ml_forecaster": {"wondrous_octopus", "connector_signals", "near_close_dca"},
    "wondrous_octopus": {"ml_forecaster", "connector_signals", "near_close_dca"},
    "connector_signals": {"ml_forecaster", "wondrous_octopus", "near_close_dca"},
    "market_data_ingest": {"ml_forecaster", "wondrous_octopus", "connector_signals", "near_close_dca"},
}


def _imported_module_names(py_file: Path) -> set[str]:
    tree = ast.parse(py_file.read_text(), filename=str(py_file))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name.split(".")[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            names.add(node.module.split(".")[0])
    return names


def test_no_forbidden_cross_imports() -> None:
    """Fails with a specific file and forbidden name on any violation.
    A package not found on disk at REPO_ROOT is skipped, not failed --
    see the module docstring for why that needs DCA_REPO_ROOT once this
    package is actually placed inside the real repo."""
    violations: list[str] = []
    found_ml_forecaster_or_octopus = False
    for package, forbidden in FORBIDDEN_IMPORTS.items():
        package_dir = REPO_ROOT / package
        if not package_dir.exists():
            continue
        if package in ("ml_forecaster", "wondrous_octopus"):
            found_ml_forecaster_or_octopus = True
        for py_file in package_dir.rglob("*.py"):
            hit = _imported_module_names(py_file) & forbidden
            if hit:
                violations.append(f"{py_file.relative_to(REPO_ROOT)} imports forbidden {sorted(hit)}")
    assert not violations, "Architecture boundary violated:\n" + "\n".join(violations)
    if not found_ml_forecaster_or_octopus:
        warnings.warn(
            f"ml_forecaster/ and wondrous_octopus/ were not found at {REPO_ROOT} -- "
            "this test only checked whatever packages ARE present there. Set "
            "DCA_REPO_ROOT once this package is placed inside the real repo, "
            "next to those two.",
            stacklevel=1,
        )


def test_dca_shared_interfaces_has_no_forbidden_imports() -> None:
    """Meaningful right now with no configuration: the one package
    guaranteed to be on disk relative to this test file regardless of
    where the wider repo puts everything else."""
    this_package_root = Path(__file__).resolve().parents[1]
    shared = this_package_root / "dca_shared_interfaces"
    assert shared.exists(), "dca_shared_interfaces/ not found next to tests/ -- check package layout"
    forbidden = {"ml_forecaster", "wondrous_octopus", "connector_signals",
                 "market_data_ingest", "near_close_dca"}
    violations = []
    for py_file in shared.rglob("*.py"):
        hit = _imported_module_names(py_file) & forbidden
        if hit:
            violations.append(f"{py_file.relative_to(this_package_root)} imports forbidden {sorted(hit)}")
    assert not violations, "dca_shared_interfaces boundary violated:\n" + "\n".join(violations)
